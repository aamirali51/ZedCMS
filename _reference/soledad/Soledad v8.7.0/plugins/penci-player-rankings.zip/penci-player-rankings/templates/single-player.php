<?php
get_header();
?>
    <div class="container-single-page container-default-page">
        <div class="container">
            <div id="main" class="penci-main-single-page-default">
                <div class="hub-player">
                    <div class="grid-stack">
                        <div class="layer layer1">
                            <div class="penci-prankings-grid">
                                <div class="penci-prankings-box-wrapper penci-prankings-col player-data">
                                    <div class="penci-prankings-box-wrapper player-namecard">
                                        <div class="penci-prankings-box-wrapper spacer"></div>
                                        <div class="penci-prankings-box-wrapper penci-prankings-wide player-namecard-data">
                                            <div class="title">
                                                <div class="first"><?php echo get_post_meta( get_the_ID(), 'pencibm_fname', true ); ?></div>
                                                <div class="last"><?php echo get_post_meta( get_the_ID(), 'pencibm_lname', true ); ?></div>
                                            </div>
                                            <div class="rank">
                                                <span>#</span><?php echo penci_player_single_ranking(); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="penci-prankings-box-wrapper player-stats">
                                        <div class="penci-prankings-box-wrapper spacer"></div>
                                        <div class="penci-prankings-box-wrapper penci-prankings-wide player-stats-data">
                                            <div class="penci-prankings-box-wrapper bio-data">
                                                <div class="player-bio-data">
                                                    <table>
                                                        <tbody>
														<?php
														$default_metas = [
															'fname',
															'lname',
															'alias',
															'country',
															'hometown',
															'birthday',
															'height',
														];
														foreach ( $default_metas as $meta ) :
															$meta_value = get_post_meta( get_the_ID(), 'pencibm_' . $meta, true );
                                                            if ( $meta_value == '' ) {
                                                                continue;
                                                            }
                                                            if ( $meta == 'country' ) {
                                                                $meta_value = penci_player_rankings_country_list( $meta_value );
                                                            }
															?>
                                                            <tr>
                                                                <td class="stat-label"><?php echo penci_player_rankings_texts( $meta ); ?></td>
                                                                <td class="stat-value"><?php esc_html_e( $meta_value ); ?></td>
                                                            </tr>
														<?php endforeach; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                            <div class="penci-prankings-box-wrapper wnt-data">
                                                <div class="wnt-stats">
                                                    <table>
                                                        <tbody>
														<?php
														$extra_fields = get_post_meta( get_the_ID(), 'pencibm_user_fields', true );
														if ( ! empty( $extra_fields ) ):
															foreach ( $extra_fields as $field => $field_data ):
																?>
                                                                <tr>
																	<?php if ( isset( $field_data['name'] ) ): ?>
                                                                        <td class="stat-label"><?php echo esc_html( $field_data['name'] ); ?></td>
																	<?php endif; ?>
																	<?php if ( isset( $field_data['url'] ) ): ?>
                                                                        <td class="stat-value stat-number "><?php echo esc_html( $field_data['url'] ); ?></td>
																	<?php endif; ?>
                                                                </tr>
															<?php endforeach;
														endif; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="layer layer2">
                            <div class="penci-prankings-grid">
								
                                <div class="penci-prankings-box-wrapper player-image">
                                    <div class="foreground">

                                        <?php
                                        if ( has_post_thumbnail() ) {
                                            echo get_the_post_thumbnail( get_the_ID(), 'penci-full-thumb' );
                                        } else {
                                            echo penci_player_rankings_df_ava();                                        
                                        }
                                        ?>

                                    </div>
                                    <div class="background">
                                        <div class="penci-prankings-grid">
                                            <div class="penci-prankings-box-wrapper penci-prankings-col">
                                                <div class="penci-prankings-box-wrapper player-namecard"></div>
                                                <div class="penci-prankings-box-wrapper player-stats"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="penci-prankings-box-wrapper penci-prankings-col penci-prankings-wide spacer">
                                </div>
								
                            </div>
                        </div>
                    </div>
                </div>
                <div class="penci-bm-user-desc entry-content">
					<?php
					while ( have_posts() ) : the_post();
						the_content();
					endwhile;
					?>
                </div>
            </div>
        </div>
    </div><!-- ooo -->
<?php get_footer(); ?>