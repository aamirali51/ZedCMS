<?php
$options   = array();

$options[] = array(
	'id'          => 'penci_player_rankings_player_header',
	'transport'   => 'postMessage',
	'type'        => 'soledad-fw-header',
	'label'       => esc_html__( 'URL Settings', 'penci-player-rankings' ),
);

$options[] = array(
	'id'          => 'penci_player_rankings_player_slug',
	'transport'   => 'postMessage',
	'default'     => 'player',
	'type'        => 'soledad-fw-text',
	'label'       => esc_html__( 'Player Rankings URL Slug', 'penci-player-rankings' ),
);

$options[] = array(
	'id'          => 'penci_player_rankings_player_team_slug',
	'transport'   => 'postMessage',
	'default'     => 'team',
	'type'        => 'soledad-fw-text',
	'label'       => esc_html__( 'Player Team URL Slug', 'penci-player-rankings' ),
);

$options[] = array(
	'id'          => 'penci_player_rankings_player_header_01',
	'transport'   => 'postMessage',
	'type'        => 'soledad-fw-header',
	'label'       => esc_html__( 'Archive Settings', 'penci-player-rankings' ),
);

$options[] = array(
	'id'        => 'penci_player_rankings_acol',
	'transport' => 'postMessage',
	'default'   => '4',
	'type'      => 'soledad-fw-select',
	'label'     => esc_html__( 'Columns', 'penci-paywall' ),
	'choices'   => array(
		'2' => '2 Columns',
		'3' => '3 Columns',
		'4' => '4 Columns',
		'5' => '5 Columns',
		'6' => '6 Columns',
	),
);

$options[] = array(
	'id'        => 'penci_player_rankings_amcol',
	'transport' => 'postMessage',
	'default'   => '2',
	'type'      => 'soledad-fw-select',
	'label'     => esc_html__( 'Mobile Columns', 'penci-paywall' ),
	'choices'   => array(
		'2' => '2 Columns',
		'3' => '3 Columns',
	),
);

return $options;