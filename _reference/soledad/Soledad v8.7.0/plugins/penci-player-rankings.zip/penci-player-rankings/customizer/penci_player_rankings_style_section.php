<?php
$options   = array();

$options[] = array(
	'id'          => 'penci_player_rankings_player_h1',
	'transport'   => 'postMessage',
	'type'        => 'soledad-fw-header',
	'label'       => esc_html__( 'Archive Pages', 'penci-player-rankings' ),
);

$options[] = array(
	'id'        => 'penci_player_general_bgcolor',
	'transport' => 'postMessage',
	'default'   => '',
	'type'      => 'soledad-fw-color',
	'label'     => esc_html__( 'General Background Color', 'penci-paywall' ),
);

$options[] = array(
	'id'        => 'penci_player_general_bdcolor',
	'transport' => 'postMessage',
	'default'   => '',
	'type'      => 'soledad-fw-color',
	'label'     => esc_html__( 'User Border Color', 'penci-paywall' ),
);

$options[] = array(
	'id'        => 'penci_player_general_rankcolor',
	'transport' => 'postMessage',
	'default'   => '',
	'type'      => 'soledad-fw-color',
	'label'     => esc_html__( 'Ranking Color', 'penci-paywall' ),
);

$options[] = array(
	'id'        => 'penci_player_general_namecolor',
	'transport' => 'postMessage',
	'default'   => '',
	'type'      => 'soledad-fw-color',
	'label'     => esc_html__( 'Name Color', 'penci-paywall' ),
);

$options[] = array(
	'id'          => 'penci_player_rankings_player_h2',
	'transport'   => 'postMessage',
	'type'        => 'soledad-fw-header',
	'label'       => esc_html__( 'Single Player', 'penci-player-rankings' ),
);

$options[] = array(
	'id'        => 'penci_player_s_bdt_color',
	'transport' => 'postMessage',
	'default'   => '',
	'type'      => 'soledad-fw-color',
	'label'     => esc_html__( 'Border Top Color', 'penci-paywall' ),
);

$options[] = array(
	'id'        => 'penci_player_s_name_color',
	'transport' => 'postMessage',
	'default'   => '',
	'type'      => 'soledad-fw-color',
	'label'     => esc_html__( 'Name Color', 'penci-paywall' ),
);

$options[] = array(
	'id'        => 'penci_player_s_rank_color',
	'transport' => 'postMessage',
	'default'   => '',
	'type'      => 'soledad-fw-color',
	'label'     => esc_html__( 'Rank Color', 'penci-paywall' ),
);

$options[] = array(
	'id'        => 'penci_player_s_stats_bgcolor',
	'transport' => 'postMessage',
	'default'   => '',
	'type'      => 'soledad-fw-color',
	'label'     => esc_html__( 'Stats Background Color', 'penci-paywall' ),
);

$options[] = array(
	'id'        => 'penci_player_s_stats_bdcolor',
	'transport' => 'postMessage',
	'default'   => '',
	'type'      => 'soledad-fw-color',
	'label'     => esc_html__( 'Stats Border Color', 'penci-paywall' ),
);

$options[] = array(
	'id'        => 'penci_player_s_stat_lbcolor',
	'transport' => 'postMessage',
	'default'   => '',
	'type'      => 'soledad-fw-color',
	'label'     => esc_html__( 'Stats: Label Color', 'penci-paywall' ),
);

$options[] = array(
	'id'        => 'penci_player_s_stat_vlcolor',
	'transport' => 'postMessage',
	'default'   => '',
	'type'      => 'soledad-fw-color',
	'label'     => esc_html__( 'Stats: Value Color', 'penci-paywall' ),
);

return $options;