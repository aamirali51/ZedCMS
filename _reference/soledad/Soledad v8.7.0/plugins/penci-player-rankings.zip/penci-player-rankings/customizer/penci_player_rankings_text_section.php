<?php
$options = array();

$texts = penci_player_rankings_default_texts();

foreach ( $texts as $key => $value ) {
	$options[ $key ] = array(
		'id'        => 'penci_player_rankings_text_' . $key,
		'transport' => 'postMessage',
		'type'      => 'soledad-fw-text',
		'label'     => esc_html__( 'Text: ', 'penci-player-rankings' ) . $value,
		'default'   => $value,
	);
}

return $options;