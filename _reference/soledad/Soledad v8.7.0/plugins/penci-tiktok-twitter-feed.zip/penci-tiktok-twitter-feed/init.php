<?php
/*
Plugin Name: Penci Social Feed
Plugin URI: http://pencidesign.com/
Description: A plugin to help you connect to some socials media ( like Twitter ) to show the feed of those socials media.
Version: 1.1
Author: PenciDesign
Author URI: http://themeforest.net/user/pencidesign?ref=pencidesign
*/

define( 'PENCI_SOLEDAD_SOCIAL_FEED', '1.1' );
require_once dirname( __FILE__ ) . '/lib/twitter.php';
