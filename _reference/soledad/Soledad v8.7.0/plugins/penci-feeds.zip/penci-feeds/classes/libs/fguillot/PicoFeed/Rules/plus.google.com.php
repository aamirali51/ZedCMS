<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'https://plus.google.com/+LarryPage/posts/Lh8SKC6sED1',
            'body' => array(
                '//div[@role="article"]/div[contains(@class, "eE")]',
            ),
        )
    )
);
