<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.macg.co//logiciels/2014/05/feedly-sameliore-un-petit-peu-sur-mac-82205',
            'body' => array(
                '//div[contains(@class, "field-name-body")]'
            ),
            'strip' => array(
            ),
        )
    )
);