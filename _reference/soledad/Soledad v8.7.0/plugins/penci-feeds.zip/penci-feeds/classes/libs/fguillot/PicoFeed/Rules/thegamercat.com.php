<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.thegamercat.com/comic/just-no/',
            'body' => array('//div[@id="comic"] | //div[@class="post-content"]/div[@class="entry"]/p'),
            'strip' => array(),
        )
    )
);