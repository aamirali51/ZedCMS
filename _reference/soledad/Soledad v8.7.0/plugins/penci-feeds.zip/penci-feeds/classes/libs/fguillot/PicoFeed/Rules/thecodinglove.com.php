<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://thecodinglove.com/post/116897934767',
            'body' => array('//div[@class="bodytype"]'),
            'strip' => array(),
        )
    )
);