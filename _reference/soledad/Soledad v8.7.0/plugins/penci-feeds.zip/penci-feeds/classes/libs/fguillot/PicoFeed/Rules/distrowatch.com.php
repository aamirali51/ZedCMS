<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://distrowatch.com/?newsid=08355',
            'body' => array(
                '//td[@class="NewsText"][1]',
            ),
            'strip' => array(
            )
        )
    )
);