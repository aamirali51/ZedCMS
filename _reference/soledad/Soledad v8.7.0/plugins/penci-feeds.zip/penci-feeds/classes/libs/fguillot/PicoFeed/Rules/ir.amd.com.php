<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'body' => array('//span[@class="ccbnTxt"]'),
            'strip' => array(),
            'test_url' => 'http://ir.amd.com/phoenix.zhtml?c=74093&p=RssLanding&cat=news&id=2055819',
        )
    ),
);
