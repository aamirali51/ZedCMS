<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.fastcodesign.com/3026548/exposure/peek-inside-the-worlds-forbidden-subway-tunnels',
            'body' => array(
                '//article[contains(@class, "body prose")]',
            ),
            'strip' => array(
            )
        )
    )
);
