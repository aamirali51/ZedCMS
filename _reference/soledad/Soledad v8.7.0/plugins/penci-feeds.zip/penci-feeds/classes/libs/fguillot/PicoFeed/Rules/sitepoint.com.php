<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.sitepoint.com/creating-hello-world-app-swift/',
            'body' => array(
                '//section[@class="article_body"]',
            ),
            'strip' => array(
            ),
        )
    )
);