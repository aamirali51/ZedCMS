<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.version2.dk/artikel/surface-pro-2-fungerer-bedre-til-arbejde-end-fornoejelse-55195',
            'body' => array(
                '//section[contains(@class, "teaser")]',
                '//section[contains(@class, "body")]',
            )
        )
    )
);