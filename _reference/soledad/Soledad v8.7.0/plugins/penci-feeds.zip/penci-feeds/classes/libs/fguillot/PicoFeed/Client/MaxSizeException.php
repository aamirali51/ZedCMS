<?php

namespace PicoFeed\Client;

/**
 * MaxSizeException Exception
 *
 * @author  Frederic Guillot
 * @package Client
 */
class MaxSizeException extends ClientException
{
}
