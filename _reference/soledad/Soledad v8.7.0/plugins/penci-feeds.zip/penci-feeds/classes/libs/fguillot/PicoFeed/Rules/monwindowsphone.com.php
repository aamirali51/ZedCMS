<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.monwindowsphone.com/tout-savoir-sur-le-centre-d-action-de-windows-phone-8-1-t40574.html',
            'body' => array(
                '//div[@class="blog-post-body"]'
            ),
            'strip' => array(
            ),
        )
    )
);
