<?php
return array(
    'filter' => array(
        '%.*%' => array(
             '%-\\d+x\\d+%' => "",
        )
    )
);
