<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://pastebin.com/ed1pP9Ak',
            'body' => array(
                '//div[@class="text"]',
            ),
            'strip' => array(
            )
        )
    )
);
