<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.areadvd.de/news/daily-deals-angebote-bei-lautsprecher-teufel-3/',
            'body' => array('//div[contains(@class,"entry")]'),
            'strip' => array(),
        )
    )
);