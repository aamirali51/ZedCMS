<?php

namespace PicoFeed;

use Exception;

/**
 * PicoFeedException Exception
 *
 * @author  Frederic Guillot
 * @package exception
 */
abstract class PicoFeedException extends Exception
{
}
