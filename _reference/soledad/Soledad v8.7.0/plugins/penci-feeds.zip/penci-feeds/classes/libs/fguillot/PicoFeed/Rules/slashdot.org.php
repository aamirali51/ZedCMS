<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://science.slashdot.org/story/15/04/20/0528253/pull-top-can-tabs-at-50-reach-historic-archaeological-status',
            'body' => array(
                '//article/div[@class="body"] | //article[@class="layout-article"]/div[@class="elips"]'),
            'strip' => array(),
        )
    )
);