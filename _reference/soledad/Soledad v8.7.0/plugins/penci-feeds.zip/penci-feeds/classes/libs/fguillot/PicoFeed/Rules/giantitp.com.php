<?php
return array(
    'grabber' => array(
        '%/comics/oots.*%' => array(
	    'test_url' => 'http://www.giantitp.com/comics/oots0989.html',
	    'body' => array(
	        '//td[@align="center"]/img'
	    ),
	    'strip' => array()
	)
    )
);
