<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://ing.dk/artikel/smart-husisolering-og-styring-skal-mindske-japans-energikrise-164517',
            'body' => array(
                '//section[contains(@class, "teaser")]',
                '//section[contains(@class, "body")]',
            )
        )
    )
);