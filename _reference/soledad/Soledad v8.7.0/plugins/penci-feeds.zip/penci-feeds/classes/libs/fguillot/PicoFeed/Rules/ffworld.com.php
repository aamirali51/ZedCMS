<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.ffworld.com/?rub=news&page=voir&id=2709',
            'body' => array(
                '//div[@class="news_body"]',
            ),
            'strip' => array(
            )
        )
    )
);
