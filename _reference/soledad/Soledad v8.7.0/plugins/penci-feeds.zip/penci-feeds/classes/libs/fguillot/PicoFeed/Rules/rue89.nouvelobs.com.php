<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://rue89.feedsportal.com/c/33822/f/608948/s/30999fa0/sc/24/l/0L0Srue890N0C20A130C0A80C30A0Cfaisait0Eboris0Eboillon0Eex0Esarko0Eboy0E350A0E0A0A0A0Eeuros0Egare0Enord0E245315/story01.htm',
            'body' => array(
                '//*[@id="article"]/div[contains(@class, "content")]',
            ),
            'strip' => array(
            )
        )
    )
);