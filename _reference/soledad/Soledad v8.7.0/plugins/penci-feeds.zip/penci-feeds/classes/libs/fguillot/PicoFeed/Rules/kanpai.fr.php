<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.kanpai.fr/japon/comment-donner-lheure-en-japonais.html',
            'body' => array(
                '//div[@class="single-left"]',
            ),
            'strip' => array(
            )
        )
    )
);