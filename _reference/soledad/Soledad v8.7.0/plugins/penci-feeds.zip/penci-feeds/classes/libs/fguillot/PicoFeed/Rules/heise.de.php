<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.heise.de/security/meldung/BND-300-Millionen-Euro-fuer-Fruehwarnsystem-gegen-Cyber-Attacken-2192237.html',
            'body' => array(
                '//div[@class="meldung_wrapper"]'
            )
        )
    )
);
