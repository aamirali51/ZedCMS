<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://karriere.jobfinder.dk/artikel/dansk-professor-skal-lede-smart-grid-forskning-20-millioner-dollars-763',
            'body' => array(
                '//section[contains(@class, "teaser")]',
                '//section[contains(@class, "body")]',
            )
        )
    )
);