<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://maximumble.thebookofbiff.com/2015/04/20/1084-change/',
            'body' => array('//div[@id="comic"]/div/a/img'),
            'strip' => array(),
        )
    )
);