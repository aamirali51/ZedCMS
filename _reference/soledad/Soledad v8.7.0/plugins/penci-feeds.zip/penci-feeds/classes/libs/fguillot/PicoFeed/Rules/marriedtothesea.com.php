<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.marriedtothesea.com/index.php?date=052915',
            'body' => array(
                '//div[@align]/a/img',
            ),
            'strip' => array(),
        )
    )
);
