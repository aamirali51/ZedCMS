<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.fastcoexist.com/3026114/take-a-seat-on-this-gates-funded-future-toilet-that-will-change-how-we-think-about-poop',
            'body' => array(
                '//article[contains(@class, "body prose")]',
            ),
            'strip' => array(
            )
        )
    )
);
