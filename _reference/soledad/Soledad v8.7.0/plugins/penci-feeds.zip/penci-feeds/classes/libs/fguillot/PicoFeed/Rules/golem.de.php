<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.golem.de/news/breko-telekom-verzoegert-gezielt-den-vectoring-ausbau-1311-102974.html',
            'body' => array(
                '//header[@class="cluster-header"]',
                '//div[@class="formatted"]'
            )
        )
    )
);