<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://blog.fefe.de/?ts=ad706a73',
            'body' => array(
                '/html/body/ul'
            ),
            'strip' => array(
            ),
        )
    )
);