<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.pixelbeat.org/programming/sigpipe_handling.html#1425573246',
            'body' => array(
                '//div[@class="contentText"]',
            ),
            'strip' => array(),
        )
    )
);
