<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://mokepon.smackjeeves.com/comics/2120096/chapter-9-page-68/',
            'body' => array('//*[@id="comic_area_inner"]/img | //*[@id="comic_area_inner"]/a/img'),
            'strip' => array(),
        )
    )
);