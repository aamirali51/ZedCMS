<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'body' => array('//*[@id="comic"] | //*[@class="post-image"]'),
            'strip' => array(),
            'test_url' => 'http://www.fowllanguagecomics.com/comic/working-out/'
        )
    )
);
