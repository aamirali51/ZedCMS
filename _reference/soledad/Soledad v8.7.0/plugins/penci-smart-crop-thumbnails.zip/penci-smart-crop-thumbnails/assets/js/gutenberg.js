jQuery(function($){
	// nothing special  
});