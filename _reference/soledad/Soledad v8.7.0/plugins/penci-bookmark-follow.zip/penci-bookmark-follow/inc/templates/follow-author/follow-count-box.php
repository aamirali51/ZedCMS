<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly
?>
<div class="penci_bl_followers_message">
    <div class="penci-bf-tooltip-inner"><?php echo $follow_message; ?></div>
</div><!--penci_bl_followers_message-->